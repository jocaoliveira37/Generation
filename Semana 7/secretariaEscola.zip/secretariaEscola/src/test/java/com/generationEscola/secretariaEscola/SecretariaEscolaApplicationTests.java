package com.generationEscola.secretariaEscola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretariaEscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
