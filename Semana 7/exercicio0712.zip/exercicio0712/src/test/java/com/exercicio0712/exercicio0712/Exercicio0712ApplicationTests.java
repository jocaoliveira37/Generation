package com.exercicio0712.exercicio0712;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio0712ApplicationTests {

	@Test
	void contextLoads() {
	}

}
