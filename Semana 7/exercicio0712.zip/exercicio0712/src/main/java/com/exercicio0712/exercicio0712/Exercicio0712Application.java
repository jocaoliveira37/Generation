package com.exercicio0712.exercicio0712;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio0712Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio0712Application.class, args);
	}

}
